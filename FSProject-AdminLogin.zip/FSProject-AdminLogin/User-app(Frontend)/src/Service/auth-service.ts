import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../Interface/User';
import { Employee } from '../Interface/Employee';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  
    constructor(private http:HttpClient){}

private apiUrl = "https://localhost:7264/api/Auth";

register(user: User) {
  return this.http.post(`${this.apiUrl}/register`, user);
}

login(username: string, password: string) {
  return this.http.post<any>(`${this.apiUrl}/login`, {
    username,
    password
  });
}

view() {
  return this.http.get<Employee[]>(
    "https://localhost:7264/api/Employee"
  );
}

}
