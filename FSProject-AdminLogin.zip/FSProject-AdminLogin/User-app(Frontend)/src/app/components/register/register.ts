import { FormsModule } from '@angular/forms';
import { Component } from '@angular/core';
import { AuthService } from '../../../Service/auth-service';
import { Router } from '@angular/router';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [RouterModule, FormsModule],
  templateUrl: './register.html',
  styleUrl: './register.css'
})
export class Register {

  constructor(private auth: AuthService, private router: Router) {}

  register(username: string, password: string,role: string) {

    console.log("Register clicked");

    const user = { username,password,role};

    this.auth.register(user).subscribe({
      next: (res) => {
        console.log("Registered:", res);
        this.router.navigate(['/login']);
      },
      error: (err) => {
        console.log("Register error:", err);
      }
    });
  }
}
