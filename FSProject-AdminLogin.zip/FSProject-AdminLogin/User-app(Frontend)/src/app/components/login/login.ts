import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router';
import { AuthService } from '../../../Service/auth-service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,   // 🔥 ADD THIS
  imports: [RouterModule, FormsModule], // 🔥 Add FormsModule
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {

  constructor(private auth: AuthService, private router: Router) {}

  login(username: string, password: string) {

    console.log("LOGIN CLICKED");  // Debug line

    this.auth.login(username, password).subscribe({
      next: (response) => {
        console.log("Login success:", response);

        localStorage.setItem('token', response.token);
        this.router.navigate(['/view']);
      },
      error: (error) => {
        console.log("Login failed:", error);
      }
    });
  }
}
